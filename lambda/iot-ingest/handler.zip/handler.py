"""
IoT Message Ingest Handler
Processes MQTT messages and updates DynamoDB tables
Fixed to work with existing deployment environment
"""
import json
import boto3
import os
import traceback
from datetime import datetime


# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')

# Use the existing table names from the deployed environment
try:
    machine_state_table = dynamodb.Table(os.environ.get('MACHINE_STATE_TABLE', 'gym-machine-states'))  # Time-series table
    aggregates_table = dynamodb.Table(os.environ.get('AGGREGATES_TABLE', 'gym-aggregates'))
    # Try the current state table for latest machine status
    current_state_table = dynamodb.Table('gym-pulse-current-state')
    # Also try the new table names if they exist
    events_table = dynamodb.Table(os.environ.get('EVENTS_TABLE', 'gym-pulse-events'))
    alerts_table = dynamodb.Table(os.environ.get('ALERTS_TABLE', 'gym-pulse-alerts'))
    print("Initialized all DynamoDB tables successfully")
except Exception as e:
    print(f"Warning: Could not initialize all tables: {e}")


def detect_transition(previous_state, new_state):
    """
    Detect state transitions between machine states
    Returns: 'initialized', 'freed', 'occupied', or 'no_change'
    """
    if previous_state is None:
        return 'initialized'
    elif previous_state != new_state:
        return 'freed' if new_state == 'free' else 'occupied'
    else:
        return 'no_change'


def broadcast_to_websocket_clients(message):
    """
    Broadcast real-time update to WebSocket clients
    Currently logs the message, ready for actual WebSocket API integration
    """
    try:
        # TODO: Replace with actual WebSocket API broadcasting
        # This would typically:
        # 1. Query connections table for active WebSocket connections
        # 2. Filter connections interested in this gym/category/machine
        # 3. Send message to each active connection via API Gateway Management API
        
        print(f"Broadcasting to WebSocket clients: {json.dumps(message)}")
        
        # For now, we'll just log the structured message that would be sent
        # When WebSocket API is ready, this function will be enhanced
        
        return True
    except Exception as e:
        print(f"Error broadcasting WebSocket message: {e}")
        return False


def lambda_handler(event, context):
    """
    Process IoT message from MQTT topic
    Fixed to handle the actual IoT Rule event format
    """
    try:
        print(f"Received IoT event: {json.dumps(event)}")
        
        # Handle different event formats
        # IoT Rule sends the payload directly, not wrapped
        if isinstance(event, dict):
            if 'machineId' in event:
                # Direct payload format
                payload = event
                topic = event.get('topic', 'unknown')
            elif 'payload' in event:
                # Wrapped payload format
                payload = json.loads(event.get('payload', '{}')) if isinstance(event.get('payload'), str) else event.get('payload', {})
                topic = event.get('topic', 'unknown')
            else:
                # Try to parse as stringified JSON
                if isinstance(event, str):
                    payload = json.loads(event)
                else:
                    payload = event
                topic = payload.get('topic', 'unknown')
        else:
            raise ValueError(f"Unexpected event format: {type(event)}")
        
        # Extract machine data
        machine_id = payload.get('machineId')
        status = payload.get('status')  # 'occupied' or 'free'
        timestamp = payload.get('timestamp', int(datetime.now().timestamp()))
        gym_id = payload.get('gymId', 'unknown')
        category = payload.get('category', 'unknown')
        
        print(f"Parsed: machineId={machine_id}, status={status}, gymId={gym_id}, category={category}")
        
        if not machine_id or not status:
            raise ValueError("Missing machineId or status in payload")
        
        # Get previous state to detect transitions
        previous_state = None
        transition_type = None
        try:
            response = current_state_table.get_item(
                Key={'machineId': machine_id}
            )
            if 'Item' in response:
                previous_state = response['Item'].get('status')
                print(f"Previous state for {machine_id}: {previous_state}")
            else:
                print(f"First-time registration for machine {machine_id}")
        except Exception as e:
            print(f"Could not query previous state: {e}")
        
        # Detect state transition
        transition_type = detect_transition(previous_state, status)
        print(f"State transition for {machine_id}: {transition_type}")
        
        # Timestamp validation (prevent out-of-order messages)
        current_time = int(datetime.now().timestamp())
        if previous_state and abs(int(timestamp) - current_time) > 300:  # 5 minute tolerance
            print(f"Warning: Message timestamp {timestamp} is >5 minutes from current time {current_time}")
            # Use current time if timestamp is too old/future
            timestamp = current_time
        
        # Only process if this is a real transition or new machine
        if transition_type in ['initialized', 'freed', 'occupied']:
            print(f"Processing {transition_type} transition for {machine_id}")
        elif transition_type == 'no_change':
            print(f"No state change for {machine_id}, updating timestamp only")
        
        # Write to time-series machine state table (with composite key)
        machine_state_table.put_item(
            Item={
                'machineId': machine_id,
                'timestamp': int(timestamp),  # This is the sort key
                'status': status,
                'gymId': gym_id,
                'category': category,
                'topic': topic
            }
        )
        print(f"Recorded state event for {machine_id} at {timestamp}")
        
        # Update current state table with latest status
        try:
            current_state_table.put_item(
                Item={
                    'machineId': machine_id,
                    'status': status,
                    'lastUpdate': int(timestamp),
                    'gymId': gym_id,
                    'category': category,
                    'topic': topic
                }
            )
            print(f"Updated current state for {machine_id}")
        except Exception as e:
            print(f"Could not write to current state table: {e}")
        
        # Try to write to events table if it exists (only for real transitions)
        try:
            if transition_type != 'no_change':  # Only record actual state changes
                events_table.put_item(
                    Item={
                        'machineId': machine_id,
                        'timestamp': int(timestamp),
                        'status': status,
                        'transition': transition_type,
                        'gymId': gym_id,
                        'category': category,
                        'ttl': int(timestamp) + (30 * 24 * 3600)  # 30 days TTL
                    }
                )
                print(f"Recorded {transition_type} event for {machine_id}")
            else:
                print(f"Skipped recording no-change event for {machine_id}")
        except Exception as e:
            print(f"Could not write to events table: {e}")
        
        # Send real-time WebSocket notification for state transitions
        if transition_type in ['initialized', 'freed', 'occupied']:
            websocket_message = {
                'type': 'machine_update',
                'machineId': machine_id,
                'gymId': gym_id,
                'category': category,
                'status': status,
                'timestamp': int(timestamp),
                'lastChange': int(timestamp),
                'transition': transition_type
            }
            print(f"WebSocket notification prepared: {json.dumps(websocket_message)}")
            # TODO: Send to actual WebSocket connections when API is ready
            broadcast_to_websocket_clients(websocket_message)
        
        # TODO: Update aggregates for heatmaps
        # TODO: Trigger alerts if status changed to 'free'
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'IoT message processed successfully',
                'machineId': machine_id,
                'status': status,
                'timestamp': timestamp
            })
        }
        
    except Exception as e:
        error_msg = f"Error processing IoT message: {str(e)}"
        print(error_msg)
        print(traceback.format_exc())
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'event_received': str(event)
            })
        }